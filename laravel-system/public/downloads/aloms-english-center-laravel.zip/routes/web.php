<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\ExamController;
use App\Http\Controllers\InstallController;
use App\Http\Controllers\PortalController;
use App\Http\Controllers\PublicController;
use App\Http\Controllers\ShopController;
use Illuminate\Support\Facades\Route;

// Ready-to-Install Web Wizard (automatically locked after storage/installed.lock exists)
Route::prefix('install')->group(function () {
    Route::get('/', [InstallController::class, 'index'])->name('install.index');
    Route::post('/run', [InstallController::class, 'install'])->name('install.run');
});

// Public Pages
Route::get('/', [PublicController::class, 'home'])->name('home');
Route::get('/courses', [PublicController::class, 'courses'])->name('courses.index');
Route::get('/course/{slug}', [PublicController::class, 'courseDetail'])->name('courses.show');
Route::get('/instructors', [PublicController::class, 'instructors'])->name('instructors');
Route::get('/products', [ShopController::class, 'products'])->name('products');
Route::get('/ebooks', [ShopController::class, 'ebooks'])->name('ebooks');
Route::get('/board-result', [PublicController::class, 'results'])->name('results');
Route::post('/board-result/lookup', [PublicController::class, 'lookupResult'])->name('results.lookup');

// Auth
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.post');
Route::post('/register', [AuthController::class, 'register'])->name('register.post');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Authenticated Learning & Exam Routes
Route::middleware('auth')->group(function () {
    Route::get('/learn', [PublicController::class, 'learn'])->name('learn');
    Route::post('/learn/progress', [PublicController::class, 'markLessonComplete'])->name('learn.progress');

    Route::post('/courses/{course}/enroll', [PublicController::class, 'enroll'])->name('courses.enroll');

    Route::get('/exams', [ExamController::class, 'index'])->name('exams.index');
    Route::post('/exams/{exam}/submit', [ExamController::class, 'submit'])->name('exams.submit');

    Route::post('/shop/order', [ShopController::class, 'placeOrder'])->name('shop.order');
    Route::post('/ebooks/{ebook}/claim', [ShopController::class, 'claimEbook'])->name('ebooks.claim');

    // SINGLE UNIFIED MULTI-ROLE PORTAL (/portal)
    Route::prefix('portal')->group(function () {
        Route::get('/', [PortalController::class, 'index'])->name('portal.index');

        Route::middleware('role:admin')->group(function () {
            Route::post('/courses', [PortalController::class, 'storeCourse'])->name('portal.courses.store');
            Route::put('/courses/{course}', [PortalController::class, 'updateCourse'])->name('portal.courses.update');
            Route::patch('/courses/{course}/status', [PortalController::class, 'toggleCourseStatus'])->name('portal.courses.status');
            Route::post('/courses/{course}/duplicate', [PortalController::class, 'duplicateCourse'])->name('portal.courses.duplicate');
            Route::delete('/courses/{course}', [PortalController::class, 'deleteCourse'])->name('portal.courses.delete');
            Route::post('/branches', [PortalController::class, 'storeBranch'])->name('portal.branches.store');
            Route::put('/branches/{branch}', [PortalController::class, 'updateBranch'])->name('portal.branches.update');
            Route::patch('/branches/{branch}/status', [PortalController::class, 'toggleBranchStatus'])->name('portal.branches.status');
            Route::delete('/branches/{branch}', [PortalController::class, 'deleteBranch'])->name('portal.branches.delete');
            Route::post('/payment-gateways', [PortalController::class, 'storePaymentGateway'])->name('portal.gateways.store');
            Route::put('/payment-gateways/{id}', [PortalController::class, 'updatePaymentGateway'])->name('portal.gateways.update');
            Route::patch('/payment-gateways/{id}/status', [PortalController::class, 'togglePaymentGateway'])->name('portal.gateways.status');
            Route::delete('/payment-gateways/{id}', [PortalController::class, 'deletePaymentGateway'])->name('portal.gateways.delete');
            Route::post('/connectors', [PortalController::class, 'storeConnector'])->name('portal.connectors.store');
            Route::put('/connectors/{id}', [PortalController::class, 'updateConnector'])->name('portal.connectors.update');
            Route::patch('/connectors/{id}/status', [PortalController::class, 'toggleConnector'])->name('portal.connectors.status');
            Route::delete('/connectors/{id}', [PortalController::class, 'deleteConnector'])->name('portal.connectors.delete');
            Route::post('/users', [PortalController::class, 'storeUser'])->name('portal.users.store');
            Route::patch('/users/{user}/role', [PortalController::class, 'updateUserRole'])->name('portal.users.role');
            Route::post('/settings', [PortalController::class, 'updateSettings'])->name('portal.settings');
            Route::post('/header-menu', [PortalController::class, 'updateHeaderMenu'])->name('portal.menu.update');
            Route::post('/homepage/slides', [PortalController::class, 'storeHomepageSlide'])->name('portal.homepage.slides.store');
            Route::delete('/homepage/slides/{index}', [PortalController::class, 'deleteHomepageSlide'])->name('portal.homepage.slides.delete');
            Route::post('/homepage/config', [PortalController::class, 'updateHomepageConfig'])->name('portal.homepage.config');
            Route::post('/reviews', [PortalController::class, 'storeReview'])->name('portal.reviews.store');
            Route::put('/reviews/{review}', [PortalController::class, 'updateReview'])->name('portal.reviews.update');
            Route::patch('/reviews/{review}/status', [PortalController::class, 'updateReviewStatus'])->name('portal.reviews.status');
            Route::delete('/reviews/{review}', [PortalController::class, 'deleteReview'])->name('portal.reviews.delete');
            Route::post('/coupons', [PortalController::class, 'storeCoupon'])->name('portal.coupons.store');
            Route::post('/backups', [PortalController::class, 'createVerifiedBackup'])->name('portal.backups.store');
            Route::post('/recycle-bin/{item}/restore', [PortalController::class, 'restoreRecycleBin'])->name('portal.recycle.restore');
            Route::delete('/recycle-bin/{item}', [PortalController::class, 'purgeRecycleBin'])->name('portal.recycle.purge');
        });

        Route::post('/rewards/privacy', [PortalController::class, 'toggleLeaderboardPrivacy'])->name('portal.rewards.privacy');

        Route::middleware('role:admin,teacher,branch_manager')->group(function () {
            Route::post('/batches', [PortalController::class, 'storeBatch'])->name('portal.batches.store');
            Route::put('/batches/{batch}', [PortalController::class, 'updateBatch'])->name('portal.batches.update');
            Route::patch('/batches/{batch}/status', [PortalController::class, 'toggleBatchStatus'])->name('portal.batches.status');
            Route::delete('/batches/{batch}', [PortalController::class, 'deleteBatch'])->name('portal.batches.delete');
            Route::post('/attendance', [PortalController::class, 'recordAttendance'])->name('portal.attendance.store');
        });

        Route::middleware('role:admin,teacher')->group(function () {
            Route::post('/lessons', [PortalController::class, 'storeLesson'])->name('portal.lessons.store');
            Route::put('/lessons/{lesson}', [PortalController::class, 'updateLesson'])->name('portal.lessons.update');
            Route::patch('/lessons/{lesson}/live-status', [PortalController::class, 'updateLessonLiveStatus'])->name('portal.lessons.live_status');
            Route::post('/lessons/{lesson}/duplicate', [PortalController::class, 'duplicateLesson'])->name('portal.lessons.duplicate');
            Route::delete('/lessons/{lesson}', [PortalController::class, 'deleteLesson'])->name('portal.lessons.delete');
            Route::post('/exams', [PortalController::class, 'storeExam'])->name('portal.exams.store');
            Route::post('/question-bank/bulk', [PortalController::class, 'bulkImportQuestions'])->name('portal.question_bank.bulk');
            Route::post('/exams/from-bank', [PortalController::class, 'buildExamFromBank'])->name('portal.exams.from_bank');
        });

        Route::middleware('role:admin,branch_manager')->group(function () {
            Route::patch('/enrollments/{enrollment}', [PortalController::class, 'decideEnrollment'])->name('portal.enrollments.decide');
            Route::patch('/orders/{order}', [PortalController::class, 'updateOrder'])->name('portal.orders.update');
            Route::post('/payroll', [PortalController::class, 'generatePayroll'])->name('portal.payroll.store');
            Route::patch('/payroll/{payroll}/paid', [PortalController::class, 'markPayrollPaid'])->name('portal.payroll.paid');
        });
    });
});
