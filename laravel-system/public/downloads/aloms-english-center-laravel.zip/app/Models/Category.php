<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $fillable = ['name', 'slug', 'type', 'image', 'active'];

    protected $casts = ['active' => 'boolean'];
}
